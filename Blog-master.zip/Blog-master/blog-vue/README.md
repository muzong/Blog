### Blog-Vue

#### 技术栈

* vue
* vuex
* vue router
* axios
* element-ui
* mavon-editor  [开源md编辑器](https://github.com/hinesboy/mavonEditor)
* qs

#### Run

安装依赖
```
npm install
```
npm 失败的话，试试cnpm 
```
npm install -g cnpm --registry=https://registry.npm.taobao.org
cnpm install
```
运行
```
npm run dev
```

...
