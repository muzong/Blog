### Blog-Springboot

#### 技术栈

* SpringBoot
* MyBatis
* Spring Security
* JWT
* MySQL
* Swagger-UI
* SpringBoot Mail
* Druid
* Mongo
* Redis
* RabbitMQ
* RestFul API
* 前后端分离

#### Tip
maven 项目 需要maven环境

#### Run
```
blog-springboot/src/main/java/com/zzx/Application.java
```

项目打包
```
mvn clean package
```

...
